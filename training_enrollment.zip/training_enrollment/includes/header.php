<?php
// includes/header.php

$pageTitle = $pageTitle ?? 'Training Enrollment System';
$basePath = '/training_enrollment/';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>

    <!-- Connect the CSS file -->
    <link rel="stylesheet"
          href="<?= $basePath ?>css/style.css?v=2">
</head>
<body>

<header class="site-header">
    <div class="container">
        <h1>Training Enrollment System</h1>

        <nav class="site-nav">
            <a href="<?= $basePath ?>index.php">Home</a>
            <a href="<?= $basePath ?>admin/courses.php">Courses</a>
            <a href="<?= $basePath ?>admin/classes.php">Classes</a>
            <a href="<?= $basePath ?>admin/students.php">Record Student</a>
            <a href="<?= $basePath ?>admin/enroll.php">Enroll Student</a>
            <a href="<?= $basePath ?>admin/enrollments.php">Enrollments</a>
            <a href="<?= $basePath ?>admin/reports.php">Reports</a>
        </nav>
    </div>
</header>

<main class="container">