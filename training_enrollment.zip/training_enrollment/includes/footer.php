</main>

<footer class="site-footer"> <div class="container"> <p>&copy; <?= date('Y') ?> Training Enrollment System</p> <p>IPT Laboratory Activity - PHP PDO and MySQL</p> </div> </footer>

</body> </html>