Writing

-- Training Enrollment System
-- Database schema and sample data
-- Database: training_db

CREATE DATABASE IF NOT EXISTS training_db;
USE training_db;

-- 1. Students table
CREATE TABLE IF NOT EXISTS students (
student_id INT AUTO_INCREMENT PRIMARY KEY,
full_name VARCHAR(100) NOT NULL,
email VARCHAR(100),
phone VARCHAR(30),
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Courses table
CREATE TABLE IF NOT EXISTS courses (
course_id INT AUTO_INCREMENT PRIMARY KEY,
course_code VARCHAR(20) NOT NULL UNIQUE,
course_name VARCHAR(100) NOT NULL,
description TEXT
) ENGINE=InnoDB;

-- 3. Classes table
CREATE TABLE IF NOT EXISTS classes (
class_id INT AUTO_INCREMENT PRIMARY KEY,
course_id INT NOT NULL,
class_code VARCHAR(20) NOT NULL,
schedule VARCHAR(100),
instructor VARCHAR(100),
slots INT NOT NULL DEFAULT 0,
FOREIGN KEY (course_id)
REFERENCES courses(course_id)
) ENGINE=InnoDB;

-- 4. Enrollments table
CREATE TABLE IF NOT EXISTS enrollments (
enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
student_id INT NOT NULL,
class_id INT NOT NULL,
enrollment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
status VARCHAR(20) DEFAULT 'active',
FOREIGN KEY (student_id)
REFERENCES students(student_id),
FOREIGN KEY (class_id)
REFERENCES classes(class_id)
) ENGINE=InnoDB;

-- SAMPLE DATA
-- Sample courses are inserted only when their course codes do not exist.

INSERT INTO courses (course_code, course_name, description)
SELECT 'WD101', 'Web Development Fundamentals',
'Introduction to HTML, CSS, and web development.'
WHERE NOT EXISTS (
SELECT 1 FROM courses WHERE course_code = 'WD101'
);

INSERT INTO courses (course_code, course_name, description)
SELECT 'DB101', 'Database Fundamentals',
'Introduction to relational databases and SQL.'
WHERE NOT EXISTS (
SELECT 1 FROM courses WHERE course_code = 'DB101'
);

INSERT INTO courses (course_code, course_name, description)
SELECT 'PY101', 'Python Programming',
'Introduction to Python programming.'
WHERE NOT EXISTS (
SELECT 1 FROM courses WHERE course_code = 'PY101'
);

-- Sample classes
-- Each class is linked to its course using course_id.

INSERT INTO classes
(course_id, class_code, schedule, instructor, slots)
SELECT c.course_id, 'WD-F01',
'Monday, 9:00 AM - 12:00 PM',
'Alex Reyes', 20
FROM courses c
WHERE c.course_code = 'WD101'
AND NOT EXISTS (
SELECT 1 FROM classes
WHERE class_code = 'WD-F01'
);

INSERT INTO classes
(course_id, class_code, schedule, instructor, slots)
SELECT c.course_id, 'DB-F01',
'Tuesday, 1:00 PM - 4:00 PM',
'Jamie Santos', 15
FROM courses c
WHERE c.course_code = 'DB101'
AND NOT EXISTS (
SELECT 1 FROM classes
WHERE class_code = 'DB-F01'
);

INSERT INTO classes
(course_id, class_code, schedule, instructor, slots)
SELECT c.course_id, 'PY-F01',
'Friday, 9:00 AM - 12:00 PM',
'Taylor Cruz', 18
FROM courses c
WHERE c.course_code = 'PY101'
AND NOT EXISTS (
SELECT 1 FROM classes
WHERE class_code = 'PY-F01'
);

-- Sample students
-- These are not automatically enrolled in any class.

INSERT INTO students (full_name, email, phone)
SELECT 'Alex Morgan', '[alex.morgan@example.com](mailto:alex.morgan@example.com)', '09171234567'
WHERE NOT EXISTS (
SELECT 1 FROM students
WHERE email = '[alex.morgan@example.com](mailto:alex.morgan@example.com)'
);

INSERT INTO students (full_name, email, phone)
SELECT 'Jamie Taylor', '[jamie.taylor@example.com](mailto:jamie.taylor@example.com)', '09181234567'
WHERE NOT EXISTS (
SELECT 1 FROM students
WHERE email = '[jamie.taylor@example.com](mailto:jamie.taylor@example.com)'
);