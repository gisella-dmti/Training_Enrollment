php
<?php
// admin/classes.php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../classes/Course.php';
require_once __DIR__ . '/../classes/ClassSection.php';
require_once __DIR__ . '/../includes/header.php';

$courseModel = new Course($db);
$classModel = new ClassSection($db);

$message = '';
$error = '';

// Handle the Add Class form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = filter_input(INPUT_POST, 'course_id', FILTER_VALIDATE_INT);
    $class_code = trim($_POST['class_code'] ?? '');
    $schedule = trim($_POST['schedule'] ?? '');
    $instructor = trim($_POST['instructor'] ?? '');
    $slotsInput = $_POST['slots'] ?? '';

    if (
        !$course_id ||
        $class_code === '' ||
        $schedule === '' ||
        $instructor === '' ||
        $slotsInput === '' ||
        filter_var($slotsInput, FILTER_VALIDATE_INT) === false ||
        (int) $slotsInput < 0
    ) {
        $error = 'Please complete all fields and enter a valid non-negative number of slots.';
    } else {
        // Confirm that the selected course exists.
        $selectedCourse = $courseModel->find($course_id);

        if (!$selectedCourse) {
            $error = 'The selected course does not exist. Please choose a valid course.';
        } else {
            try {
                $created = $classModel->create(
                    $course_id,
                    $class_code,
                    $schedule,
                    $instructor,
                    (int) $slotsInput
                );

                if ($created) {
                    header('Location: classes.php?success=1');
                    exit;
                }

                $error = 'The class could not be added.';
            } catch (PDOException $e) {
                $error = 'Unable to add the class. Check that the class code is valid and not duplicated.';
            }
        }
    }
}

if (isset($_GET['success'])) {
    $message = 'Class added successfully!';
}

// Retrieve courses and classes through the data-access classes.
$courses = $courseModel->all();
$classes = $classModel->allWithCourse();
?>

<h1>Class Management</h1>
<p>Add class schedules and manage the available slots for each course.</p>

<?php if ($message !== ''): ?>
    <p class="success">
        <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<?php if ($error !== ''): ?>
    <p class="error">
        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<section>
    <h2>Add Class</h2>

    <?php if (empty($courses)): ?>
        <p>Please add a course first before creating a class.</p>
        <p><a href="courses.php">Go to Course Management</a></p>
    <?php else: ?>
        <form method="POST" action="classes.php">
            <div>
                <label for="course_id">Course:</label>
                <select id="course_id" name="course_id" required>
                    <option value="">-- Select a course --</option>

                    <?php foreach ($courses as $course): ?>
                        <option
                            value="<?= (int) $course['course_id'] ?>"
                            <?= (string) ($_POST['course_id'] ?? '') === (string) $course['course_id'] ? 'selected' : '' ?>
                        >
                            <?= htmlspecialchars($course['course_code'], ENT_QUOTES, 'UTF-8') ?>
                            -
                            <?= htmlspecialchars($course['course_name'], ENT_QUOTES, 'UTF-8') ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="class_code">Class Code:</label>
                <input
                    type="text"
                    id="class_code"
                    name="class_code"
                    maxlength="20"
                    value="<?= htmlspecialchars($_POST['class_code'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    required
                >
            </div>

            <div>
                <label for="schedule">Schedule:</label>
                <input
                    type="text"
                    id="schedule"
                    name="schedule"
                    maxlength="100"
                    placeholder="Example: Monday, 9:00 AM - 12:00 PM"
                    value="<?= htmlspecialchars($_POST['schedule'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    required
                >
            </div>

            <div>
                <label for="instructor">Instructor:</label>
                <input
                    type="text"
                    id="instructor"
                    name="instructor"
                    maxlength="100"
                    value="<?= htmlspecialchars($_POST['instructor'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                    required
                >
            </div>

            <div>
                <label for="slots">Available Slots:</label>
                <input
                    type="number"
                    id="slots"
                    name="slots"
                    min="0"
                    step="1"
                    value="<?= htmlspecialchars($_POST['slots'] ?? '20', ENT_QUOTES, 'UTF-8') ?>"
                    required
                >
            </div>

            <button type="submit">Add Class</button>
        </form>
    <?php endif; ?>
</section>

<section>
    <h2>Class List</h2>

    <?php if (empty($classes)): ?>
        <p>No classes have been added yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Class ID</th>
                    <th>Course</th>
                    <th>Class Code</th>
                    <th>Schedule</th>
                    <th>Instructor</th>
                    <th>Remaining Slots</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($classes as $class): ?>
                    <tr>
                        <td><?= (int) $class['class_id'] ?></td>
                        <td>
                            <?= htmlspecialchars($class['course_name'], ENT_QUOTES, 'UTF-8') ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($class['class_code'], ENT_QUOTES, 'UTF-8') ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($class['schedule'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>
                        <td>
                            <?= htmlspecialchars($class['instructor'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>
                        <td><?= (int) $class['slots'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>