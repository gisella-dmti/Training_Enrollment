<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../classes/EnrollmentRepository.php';
require_once __DIR__ . '/../classes/ClassSection.php';

$repo = new EnrollmentRepository($db);
$classModel = new ClassSection($db);

$message = '';
$error = '';
$fullName = '';
$email = '';
$phone = '';
$classId = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $classId = (int) ($_POST['class_id'] ?? 0);

    if ($fullName === '' || strlen($fullName) > 100) {
        $error = 'Enter a student name of no more than 100 characters.';
    } elseif ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid email address.';
    } elseif (strlen($email) > 254) {
        $error = 'Email address is too long.';
    } elseif (strlen($phone) > 30) {
        $error = 'Phone number must not exceed 30 characters.';
    } elseif ($classId <= 0) {
        $error = 'Please select a class.';
    } else {
        try {
            $result = $repo->recordStudent(
                $fullName,
                $email,
                $phone,
                $classId
            );

            if ($result) {
                header('Location: students.php?success=1');
                exit;
            }

            $error = 'Enrollment failed. The class may have no available slots.';
        } catch (Throwable $e) {
            $error = 'Unable to record the student. Check the class details and try again.';
        }
    }
}

if (isset($_GET['success'])) {
    $message = 'Student recorded and enrolled successfully!';
}

$classList = $classModel->allWithCourse();
$hasOpenClass = false;

foreach ($classList as $class) {
    if ((int) $class['slots'] > 0) {
        $hasOpenClass = true;
        break;
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Student Recording</h1>
<p>Record a student and enroll them in a class.</p>

<?php if ($message): ?>
    <p class="success"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<h2>Student Information</h2>

<?php if (empty($classList)): ?>
    <p>No classes are available. Add a class first.</p>
    <a href="classes.php">Go to Class Management</a>
<?php else: ?>
    <form method="POST" action="students.php">
        <p>
            <label for="full_name">Full Name:</label>
            <input type="text" id="full_name" name="full_name"
                   maxlength="100"
                   value="<?= htmlspecialchars($fullName) ?>" required>
        </p>

        <p>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email"
                   maxlength="254"
                   value="<?= htmlspecialchars($email) ?>">
        </p>

        <p>
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone"
                   maxlength="30"
                   value="<?= htmlspecialchars($phone) ?>">
        </p>

        <p>
            <label for="class_id">Select Class:</label>
            <select id="class_id" name="class_id" required>
                <option value="">-- Select Class --</option>
                <?php foreach ($classList as $class): ?>
                    <option value="<?= (int) $class['class_id'] ?>"
                        <?= $classId == $class['class_id'] ? 'selected' : '' ?>
                        <?= (int) $class['slots'] <= 0 ? 'disabled' : '' ?>>
                        <?= htmlspecialchars($class['course_name']) ?>
                        - <?= htmlspecialchars($class['class_code']) ?>
                        | <?= htmlspecialchars($class['schedule'] ?? '') ?>
                        | Slots: <?= (int) $class['slots'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <button type="submit" <?= !$hasOpenClass ? 'disabled' : '' ?>>
            Record Student and Enroll
        </button>

        <?php if (!$hasOpenClass): ?>
            <p>All classes are currently full.</p>
        <?php endif; ?>
    </form>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>