<?php
require_once __DIR__ . '/../config/db.php';

$studentCount = (int) $db->getRow(
    'SELECT COUNT(*) AS total FROM students'
)['total'];

$courseCount = (int) $db->getRow(
    'SELECT COUNT(*) AS total FROM courses'
)['total'];

$classCount = (int) $db->getRow(
    'SELECT COUNT(*) AS total FROM classes'
)['total'];

$activeEnrollmentCount = (int) $db->getRow(
    'SELECT COUNT(*) AS total
     FROM enrollments
     WHERE status = :status',
    [':status' => 'active']
)['total'];

$classReport = $db->getRows(
    "SELECT
        c.class_id,
        c.class_code,
        c.schedule,
        c.instructor,
        c.slots,
        co.course_code,
        co.course_name,
        COUNT(
            CASE WHEN e.status = :active THEN 1 END
        ) AS active_enrollments
     FROM classes c
     INNER JOIN courses co
        ON co.course_id = c.course_id
     LEFT JOIN enrollments e
        ON e.class_id = c.class_id
     GROUP BY
        c.class_id,
        c.class_code,
        c.schedule,
        c.instructor,
        c.slots,
        co.course_code,
        co.course_name
     ORDER BY co.course_name, c.class_code",
    [':active' => 'active']
);

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Summary Reports</h1>
<p>Overview of students, courses, classes, and active enrollments.</p>

<h2>System Totals</h2>

<table>
    <thead>
        <tr>
            <th>Item</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Students</td>
            <td><?= $studentCount ?></td>
        </tr>
        <tr>
            <td>Courses</td>
            <td><?= $courseCount ?></td>
        </tr>
        <tr>
            <td>Classes</td>
            <td><?= $classCount ?></td>
        </tr>
        <tr>
            <td>Active Enrollments</td>
            <td><?= $activeEnrollmentCount ?></td>
        </tr>
    </tbody>
</table>

<h2>Class Enrollment Summary</h2>

<?php if (empty($classReport)): ?>
    <p>No classes are available for reporting.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Course Code</th>
                <th>Course Name</th>
                <th>Class Code</th>
                <th>Schedule</th>
                <th>Instructor</th>
                <th>Active Enrollments</th>
                <th>Remaining Slots</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($classReport as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['course_code']) ?></td>
                <td><?= htmlspecialchars($row['course_name']) ?></td>
                <td><?= htmlspecialchars($row['class_code']) ?></td>
                <td><?= htmlspecialchars($row['schedule'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['instructor'] ?? '') ?></td>
                <td><?= (int) $row['active_enrollments'] ?></td>
                <td><?= (int) $row['slots'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>