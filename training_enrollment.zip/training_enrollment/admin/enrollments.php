<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../classes/EnrollmentRepository.php';

$repo = new EnrollmentRepository($db);
$message = '';
$error = '';

if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['action'] ?? '') === 'cancel'
) {
    $enrollmentId = filter_input(
        INPUT_POST,
        'enrollment_id',
        FILTER_VALIDATE_INT
    );

    if (!$enrollmentId) {
        $error = 'Invalid enrollment ID.';
    } else {
        try {
            if ($repo->cancel($enrollmentId)) {
                header('Location: enrollments.php?cancelled=1');
                exit;
            }

            $error = 'Unable to cancel this enrollment. It may already be cancelled.';
        } catch (Throwable $e) {
            $error = 'Unable to cancel the enrollment. Please try again.';
        }
    }
}

if (isset($_GET['cancelled'])) {
    $message = 'Enrollment cancelled successfully. The class slot should be restored.';
}

$rows = $repo->allWithDetails();

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Enrollments</h1>
<p>View enrollment details and cancel active enrollments.</p>

<?php if ($message): ?>
    <p class="success"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<h2>Enrollment List</h2>

<?php if (empty($rows)): ?>
    <p>No enrollment records found.</p>
<?php else: ?>
    <table>
        <thead>
            <tr>
                <th>Enrollment ID</th>
                <th>Student</th>
                <th>Course</th>
                <th>Class</th>
                <th>Schedule</th>
                <th>Enrollment Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($rows as $row): ?>
            <tr>
                <td><?= (int) $row['enrollment_id'] ?></td>
                <td><?= htmlspecialchars($row['full_name']) ?></td>
                <td><?= htmlspecialchars($row['course_name']) ?></td>
                <td><?= htmlspecialchars($row['class_code']) ?></td>
                <td><?= htmlspecialchars($row['schedule'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['enrollment_date'] ?? '') ?></td>
                <td><?= htmlspecialchars($row['status']) ?></td>
                <td>
                    <?php if (strtolower($row['status']) === 'active'): ?>
                        <form method="POST" action="enrollments.php"
                              onsubmit="return confirm('Cancel this enrollment?');">
                            <input type="hidden" name="action" value="cancel">
                            <input type="hidden" name="enrollment_id"
                                   value="<?= (int) $row['enrollment_id'] ?>">
                            <button type="submit">Cancel</button>
                        </form>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>