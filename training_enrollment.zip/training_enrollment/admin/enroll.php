<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../classes/EnrollmentRepository.php';
require_once __DIR__ . '/../classes/Student.php';
require_once __DIR__ . '/../classes/ClassSection.php';

$repo = new EnrollmentRepository($db);
$studentModel = new Student($db);
$classModel = new ClassSection($db);

$students = $studentModel->all();
$classes = $classModel->allWithCourse();

$message = '';
$error = '';
$studentId = '';
$classId = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $studentId = (int) ($_POST['student_id'] ?? 0);
    $classId = (int) ($_POST['class_id'] ?? 0);

    if ($studentId <= 0 || !$studentModel->find($studentId)) {
        $error = 'Please select a valid student.';
    } elseif ($classId <= 0) {
        $error = 'Please select a class.';
    } else {
        try {
            if ($repo->enroll($studentId, $classId)) {
                header('Location: enroll.php?success=1');
                exit;
            }

            $error = 'Enrollment failed. The class may be full or the student may already be enrolled.';
        } catch (Throwable $e) {
            $error = 'Unable to complete the enrollment. Check the selected student and class.';
        }
    }
}

if (isset($_GET['success'])) {
    $message = 'Student enrolled successfully!';
}

$classes = $classModel->allWithCourse();

require_once __DIR__ . '/../includes/header.php';
?>

<h1>Enroll Existing Student</h1>

<?php if ($message): ?>
    <p class="success"><?= htmlspecialchars($message) ?></p>
<?php endif; ?>

<?php if ($error): ?>
    <p class="error"><?= htmlspecialchars($error) ?></p>
<?php endif; ?>

<?php if (empty($students)): ?>
    <p>No students are registered yet.</p>
    <a href="students.php">Record a Student</a>
<?php elseif (empty($classes)): ?>
    <p>No classes are available.</p>
    <a href="classes.php">Add a Class</a>
<?php else: ?>
    <form method="POST" action="enroll.php">
        <p>
            <label for="student_id">Student:</label>
            <select id="student_id" name="student_id" required>
                <option value="">-- Select Student --</option>
                <?php foreach ($students as $student): ?>
                    <option value="<?= (int) $student['student_id'] ?>"
                        <?= $studentId == $student['student_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($student['full_name']) ?>
                        (ID: <?= (int) $student['student_id'] ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <p>
            <label for="class_id">Class:</label>
            <select id="class_id" name="class_id" required>
                <option value="">-- Select Class --</option>
                <?php foreach ($classes as $class): ?>
                    <option value="<?= (int) $class['class_id'] ?>"
                        <?= $classId == $class['class_id'] ? 'selected' : '' ?>
                        <?= (int) $class['slots'] <= 0 ? 'disabled' : '' ?>>
                        <?= htmlspecialchars($class['course_name']) ?>
                        - <?= htmlspecialchars($class['class_code']) ?>
                        | Slots: <?= (int) $class['slots'] ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>

        <button type="submit">Enroll Student</button>
    </form>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
