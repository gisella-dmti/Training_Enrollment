php
<?php
// admin/courses.php

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../classes/Course.php';
require_once __DIR__ . '/../includes/header.php';

$courseModel = new Course($db);

$message = '';
$error = '';
$editCourse = null;

// Handle adding, updating, and deleting courses
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    try {
        if ($action === 'add' || $action === 'update') {
            $course_code = trim($_POST['course_code'] ?? '');
            $course_name = trim($_POST['course_name'] ?? '');
            $description = trim($_POST['description'] ?? '');

            if ($course_code === '' || $course_name === '') {
                $error = 'Course code and course name are required.';
            } elseif ($action === 'add') {
                $courseModel->create(
                    $course_code,
                    $course_name,
                    $description
                );

                header('Location: courses.php?success=added');
                exit;
            } else {
                $course_id = filter_input(
                    INPUT_POST,
                    'course_id',
                    FILTER_VALIDATE_INT
                );

                if (!$course_id) {
                    $error = 'Invalid course ID.';
                } else {
                    $courseModel->update(
                        $course_id,
                        $course_code,
                        $course_name,
                        $description
                    );

                    header('Location: courses.php?success=updated');
                    exit;
                }
            }
        } elseif ($action === 'delete') {
            $course_id = filter_input(
                INPUT_POST,
                'course_id',
                FILTER_VALIDATE_INT
            );

            if (!$course_id) {
                $error = 'Invalid course ID.';
            } else {
                $courseModel->delete($course_id);

                header('Location: courses.php?success=deleted');
                exit;
            }
        }
    } catch (PDOException $e) {
        $error = 'The operation failed. Check whether the course code already exists or the course is being used by a class.';
    }
}

// Display success messages after redirect
if (isset($_GET['success'])) {
    $successMessages = [
        'added' => 'Course added successfully!',
        'updated' => 'Course updated successfully!',
        'deleted' => 'Course deleted successfully!'
    ];

    $message = $successMessages[$_GET['success']] ?? '';
}

// Load a course into the edit form
if (isset($_GET['edit'])) {
    $editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

    if ($editId) {
        $editCourse = $courseModel->find($editId);
    }
}

// Get all courses
$courses = $courseModel->all();
?>

<h1>Course Management</h1>
<p>Add, edit, view, and delete courses.</p>

<?php if ($message !== ''): ?>
    <p class="success">
        <?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<?php if ($error !== ''): ?>
    <p class="error">
        <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<section>
    <h2><?= $editCourse ? 'Edit Course' : 'Add Course' ?></h2>

    <form method="POST" action="courses.php">
        <input
            type="hidden"
            name="action"
            value="<?= $editCourse ? 'update' : 'add' ?>"
        >

        <?php if ($editCourse): ?>
            <input
                type="hidden"
                name="course_id"
                value="<?= (int) $editCourse['course_id'] ?>"
            >
        <?php endif; ?>

        <div>
            <label for="course_code">Course Code:</label>
            <input
                type="text"
                id="course_code"
                name="course_code"
                maxlength="20"
                value="<?= htmlspecialchars($editCourse['course_code'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >
        </div>

        <div>
            <label for="course_name">Course Name:</label>
            <input
                type="text"
                id="course_name"
                name="course_name"
                maxlength="100"
                value="<?= htmlspecialchars($editCourse['course_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                required
            >
        </div>

        <div>
            <label for="description">Description:</label>
            <textarea
                id="description"
                name="description"
                rows="4"
            ><?= htmlspecialchars($editCourse['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>
        </div>

        <button type="submit">
            <?= $editCourse ? 'Update Course' : 'Add Course' ?>
        </button>

        <?php if ($editCourse): ?>
            <a href="courses.php">Cancel Edit</a>
        <?php endif; ?>
    </form>
</section>

<section>
    <h2>Course List</h2>

    <?php if (empty($courses)): ?>
        <p>No courses have been added yet.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Course Code</th>
                    <th>Course Name</th>
                    <th>Description</th>
                    <th>Actions</th>
                </tr>
            </thead>

            <tbody>
                <?php foreach ($courses as $course): ?>
                    <tr>
                        <td><?= (int) $course['course_id'] ?></td>

                        <td>
                            <?= htmlspecialchars($course['course_code'], ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($course['course_name'], ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td>
                            <?= htmlspecialchars($course['description'] ?? '', ENT_QUOTES, 'UTF-8') ?>
                        </td>

                        <td>
                            <a href="courses.php?edit=<?= (int) $course['course_id'] ?>">
                                Edit
                            </a>

                            <form
                                method="POST"
                                action="courses.php"
                                onsubmit="return confirm('Are you sure you want to delete this course?');"
                            >
                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete"
                                >

                                <input
                                    type="hidden"
                                    name="course_id"
                                    value="<?= (int) $course['course_id'] ?>"
                                >

                                <button type="submit">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>