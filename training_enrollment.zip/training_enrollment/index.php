<?php
// index.php
$pageTitle = 'Home | Training Enrollment System';

require_once __DIR__ . '/includes/header.php';
?>

<section>
    <h2>Welcome to the Training Enrollment System</h2>

```
<p>
    This system helps the administrator manage training courses,
    class schedules, student records, and enrollments.
</p>

<p>
    Use the links below to access the different parts of the system.
</p>
```

</section>

<section>
    <h2>System Management</h2>

```
<p>
    <a class="button" href="admin/courses.php">
        Manage Courses
    </a>
</p>

<p>
    <a class="button" href="admin/classes.php">
        Manage Classes
    </a>
</p>

<p>
    <a class="button" href="admin/students.php">
        Record Student
    </a>
</p>

<p>
    <a class="button" href="admin/enroll.php">
        Enroll Existing Student
    </a>
</p>

<p>
    <a class="button" href="admin/enrollments.php">
        View Enrollments
    </a>
</p>

<p>
    <a class="button" href="admin/reports.php">
        View Reports
    </a>
</p>
```

</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
