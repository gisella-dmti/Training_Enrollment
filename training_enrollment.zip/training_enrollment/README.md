# Training Enrollment System — IPT Laboratory

A PHP and MySQL multi-table web application for managing training courses, class sections, student registrations, enrollments, cancellations, and summary reports. It uses PDO prepared statements, foreign keys, JOIN queries, input validation, and database transactions.

## Requirements
- XAMPP (Apache, MySQL/MariaDB, PHP 8+ recommended)
- A browser and phpMyAdmin
- PDO MySQL extension enabled in PHP

## Installation
1. Extract the `training_enrollment` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** from XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Select **Import**, choose `training_enrollment/sql/schema.sql`, then click **Import/Go**. The script creates `training_db` and sample courses, classes, students, and enrollments. **Warning:** re-importing this script drops and recreates the four tables.
5. Check `config/db.php`. The default XAMPP account is `root` with an empty password. If your MySQL credentials differ, set `DB_USER` and `DB_PASS` in your PHP environment or update the local configuration. Do not commit real passwords to GitHub.
6. Visit `http://localhost/training_enrollment/`.

## Main features
- Course CRUD: add, edit, search, and delete courses (deletion is blocked if class sections reference the course).
- Class management: add sections with schedule, instructor, and slot capacity.
- Student recording: validates the form and atomically inserts the student, creates an enrollment, and reserves one slot.
- Existing-student enrollment: blocks duplicate active enrollments and reserves a slot in the same transaction.
- Enrollment list: joins enrollment, student, class, and course details; filters by text and status; supports cancellation.
- Cancellation: marks an active enrollment as cancelled and restores one slot in a transaction.
- Reports: aggregate totals and per-course summaries.
- Prepared statements and HTML escaping are used for user-supplied values.

## Design patterns
**Singleton — `Database.php`:** `Database::getInstance()` returns one shared PDO connection during the request. This centralizes connection setup and attributes.

**Repository — `EnrollmentRepository.php`:** the repository groups enrollment data operations and multi-table business workflows in one class. Pages handle request input and presentation while the repository owns transaction logic.

## Database relationships
- One course can have many class sections.
- One class section can have many enrollment records.
- One student can have many enrollment records.
- `enrollments` is the junction table connecting students and class sections.

## Transaction and integrity notes
- Recording a new student starts a transaction, reserves a slot using a conditional update (`slots > 0`), inserts the student and enrollment, then commits. Any exception triggers rollback.
- Enrolling an existing student uses the same slot reservation approach and blocks duplicate active enrollment.
- Cancelling locks the enrollment row, updates status only if active, restores the class slot, and commits. Repeated cancellation is rejected.
- The schema uses InnoDB, foreign keys, indexes, and check constraints. Check-constraint behavior depends on the MySQL/MariaDB version.

## Suggested test checklist
1. Open Courses and add/edit a course; confirm it appears in the list.
2. Add a class with a few slots; confirm the course, schedule, and slot count appear.
3. Record a student into a class with slots; verify a student and enrollment row were created and slots decreased by one.
4. Try recording a student into `WD101-B` (seeded with zero slots); verify the warning appears and no partial student/enrollment rows are left.
5. Enroll an existing student in an available class; try the same active enrollment again and verify it is blocked.
6. Cancel an active enrollment; verify status changes to cancelled and the slot count increases by one.
7. Use the search and status filters on the enrollment page; open Reports.

## Screenshot evidence for the required documentation
The activity requires live screenshots; they must be captured from your own running application (do not use mock screenshots). Save screenshots in `docs/screenshots/` and insert them into `docs/DOCUMENTATION.md` with a caption:
1. Course Management — course list.
2. Add/Edit Course — filled form and updated list.
3. Class Management — course, schedule, instructor, remaining slots.
4. Student recording form.
5. Successful recording — confirmation plus database rows and reduced slot count.
6. Enrollments list — joined student/class/course details.
7. Cancelled enrollment — cancelled status and restored slot count.
8. Rollback case — full class message and proof no partial rows exist.
9. Database evidence — phpMyAdmin students, enrollments, and classes.

## Submission items from the PDF
- [x] Application source and required folder organization
- [x] Transactional enrollment repository
- [x] `sql/schema.sql` database setup/export script
- [x] README with setup and design-pattern explanation
- [ ] Live screenshots with captions (capture locally; placeholders are provided)
- [ ] Google Docs share URL (create a Google Doc, paste in documentation and screenshots, set “Anyone with the link can view”)
- [ ] Public GitHub repository URL (create/push this folder and set repository visibility to public)

This zip does not create or publish Google Docs/GitHub links automatically. Add the real links after uploading your work.
