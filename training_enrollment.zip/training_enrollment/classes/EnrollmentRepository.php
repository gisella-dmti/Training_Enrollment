<?php
/**
 * Repository centralizes multi-table enrollment workflows.
 * Each related write is atomic: either every step succeeds or all changes roll back.
 */
class EnrollmentRepository {
    private $db;
    public function __construct(PDO $db) { $this->db = $db; }

    private function reserveSlot($class_id) {
        // Atomic conditional update prevents two requests taking the last slot.
        $stmt = $this->db->prepare('UPDATE classes SET slots = slots - 1 WHERE class_id = :id AND slots > 0');
        $stmt->execute(['id' => $class_id]);
        if ($stmt->rowCount() !== 1) throw new RuntimeException('No slots available for this class.');
    }

    public function recordStudent($full_name, $email, $phone, $class_id) {
        try {
            $this->db->beginTransaction();
            $this->reserveSlot($class_id);
            $studentId = $this->db->insert('students', [
                'full_name' => $full_name,
                'email' => $email !== '' ? $email : null,
                'phone' => $phone !== '' ? $phone : null
            ]);
            $this->db->insert('enrollments', ['student_id' => $studentId, 'class_id' => $class_id, 'status' => 'active']);
            $this->db->commit();
            return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function enroll($student_id, $class_id) {
        try {
            $this->db->beginTransaction();
            $student = $this->db->prepare('SELECT student_id FROM students WHERE student_id = :id');
            $student->execute(['id' => $student_id]);
            if (!$student->fetch()) throw new RuntimeException('Student was not found.');
            $dup = $this->db->prepare("SELECT enrollment_id FROM enrollments WHERE student_id = :student AND class_id = :class AND status = 'active'");
            $dup->execute(['student' => $student_id, 'class' => $class_id]);
            if ($dup->fetch()) throw new RuntimeException('This student is already enrolled in that class.');
            $this->reserveSlot($class_id);
            $this->db->insert('enrollments', ['student_id' => $student_id, 'class_id' => $class_id, 'status' => 'active']);
            $this->db->commit(); return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function cancel($enrollment_id) {
        try {
            $this->db->beginTransaction();
            $stmt = $this->db->prepare("SELECT class_id, status FROM enrollments WHERE enrollment_id = :id FOR UPDATE");
            $stmt->execute(['id' => $enrollment_id]); $row = $stmt->fetch();
            if (!$row) throw new RuntimeException('Enrollment was not found.');
            if ($row['status'] === 'cancelled') throw new RuntimeException('This enrollment is already cancelled.');
            $update = $this->db->prepare("UPDATE enrollments SET status = 'cancelled' WHERE enrollment_id = :id AND status = 'active'");
            $update->execute(['id' => $enrollment_id]);
            if ($update->rowCount() !== 1) throw new RuntimeException('Enrollment could not be cancelled.');
            $slot = $this->db->prepare('UPDATE classes SET slots = slots + 1 WHERE class_id = :id');
            $slot->execute(['id' => $row['class_id']]);
            $this->db->commit(); return true;
        } catch (Throwable $e) {
            if ($this->db->inTransaction()) $this->db->rollBack();
            throw $e;
        }
    }

    public function allWithDetails() {
        return $this->db->query('SELECT e.enrollment_id, e.enrollment_date, e.status, s.student_id, s.full_name, s.email, c.class_id, c.class_code, c.schedule, c.instructor, co.course_code, co.course_name
            FROM enrollments e
            INNER JOIN students s ON e.student_id = s.student_id
            INNER JOIN classes c ON e.class_id = c.class_id
            INNER JOIN courses co ON c.course_id = co.course_id
            ORDER BY e.enrollment_date DESC, e.enrollment_id DESC')->fetchAll();
    }
}
