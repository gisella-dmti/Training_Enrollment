<?php
// classes/Student.php

class Student {
    private $db;

    public function __construct(PDO $db) {
        $this->db = $db;
    }

    public function find($id) {
        $sql = "SELECT * FROM students
                WHERE student_id = :id";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);

        return $stmt->fetch();
    }

    public function all() {
        $sql = "SELECT * FROM students
                ORDER BY full_name";

        $stmt = $this->db->prepare($sql);
        $stmt->execute();

        return $stmt->fetchAll();
    }
}